% NLOPT_LD_MMA: Method of Moving Asymptotes (MMA) (local, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_MMA
  val = 24;
