% NLOPT_LD_CCSAQ: CCSA (Conservative Convex Separable Approximations) with simple quadratic approximations (local, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_CCSAQ
  val = 41;
