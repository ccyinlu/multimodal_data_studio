% NLOPT_GD_MLSL_LDS: Multi-level single-linkage (MLSL), quasi-random (global, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GD_MLSL_LDS
  val = 23;
